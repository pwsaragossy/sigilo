pragma circom 2.2.2;
// Original circuits from https://github.com/iden3/circomlib.git
// Adapted and modified by Nethermind

include "./smthash_poseidon2.circom";

/*
SMTVerifierLevel
This circuit has 1 hash
Outputs according to the state.

State        root
=====        =======
top          H'(child, sibling)
i0           0
iold         old1leaf
inew         new1leaf
na           0

H' is the Hash function with the inputs shifted accordingly.
*/
template SMTVerifierLevel() {
    signal input st_top;
    signal input st_i0;
    signal input st_iold;
    signal input st_inew;
    signal input st_na;

    signal output root;
    signal input sibling;
    signal input old1leaf;
    signal input new1leaf;
    signal input lrbit;
    signal input child;

    signal aux[2];

    component proofHash = SMTHash2();
    component switcher = Switcher();

    switcher.L <== child;
    switcher.R <== sibling;

    switcher.sel <== lrbit;
    proofHash.L <== switcher.outL;
    proofHash.R <== switcher.outR;

    aux[0] <== proofHash.out * st_top;
    aux[1] <== old1leaf*st_iold;

    root <== aux[0] + aux[1] + new1leaf*st_inew;
}
